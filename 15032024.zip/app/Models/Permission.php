<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Spatie\Permission\Models\Permission as ModelsPermission;

class Permission extends ModelsPermission
{
    use HasFactory, HasUuids;
    protected $primaryKey = 'uuid';
    
    protected $fillable = [
        'name',
        'guard_name',
    ];
}
